echo "list directory"
ls
echo ""
echo "list parent direcotry"
ls ../
echo ""
echo "list root directory"
ls /
