#include <stdio.h>
#include <string.h>
#include "lxlpthread.h"
#include "util.h"

void *readdata(void *input);
void *scan(void *input);
void *compare(void *input);
void *pmerge(void *input);

int main(int argc, char* argv[]) {

    if(argc!=5) {
        printf("usage:\n");
        printf("    ./parallel3 inputfile1 inputfile2 outputfile maxThreadNum\n");

        return -1;
    }
   
    int threadNum = (int)stoi(strlen(argv[4]), argv[4]);
//    printf("threadNum = %d\n", threadNum);

    // read from input file
    struct readPara *readThreadArg[2];
    pthread_t readThread[2];
    int i;
    for(i=0; i<2; i++) {
        readThreadArg[i] = (struct readPara*)malloc(sizeof(struct readPara));
        readThreadArg[i]->filename = argv[i+1];
        pthread_create(&readThread[i], NULL, readdata, (void *)readThreadArg[i]);
    }
    for(i=0; i<2; i++) {
        pthread_join(readThread[i], NULL);
//        printarg(readThreadArg[i]);
    }

    int totalmax;
    if(readThreadArg[0]->max > readThreadArg[1]->max) {
        totalmax = readThreadArg[0]->max;
    } else {
        totalmax = readThreadArg[1]->max;
    }

    int *rec = (int *)calloc(totalmax+1, sizeof(int));

    long internal;
    if(readThreadArg[0]->number % threadNum ==0) internal = readThreadArg[0]->number / threadNum;
    else internal = readThreadArg[0]->number / threadNum + 1;
//    printf("internal = %ld\n", internal);

    // scan the array1 and record the number it has in rec
    pthread_t scanThreads[threadNum];
    struct scanPara *scanThreadArg[threadNum];
    for(i=0; i<threadNum;i++) {
        long leftb = i*internal;
        long rightb;
        if(i<threadNum-1) rightb = (i+1)*internal;
        else rightb = readThreadArg[0]->number;
//        printf("the %dth thread scan from %ld to %ld\n", i, leftb, rightb-1);
        scanThreadArg[i] = (struct scanPara*)malloc(sizeof(struct scanPara)); 
        initScanPara(scanThreadArg[i], leftb, rightb, readThreadArg[0]->number, readThreadArg[0]->array,
                totalmax+1, rec);
        pthread_create(&scanThreads[i], NULL, scan, (void *)scanThreadArg[i]);
    }
    for(i=0; i<threadNum; i++) {
        pthread_join(scanThreads[i], NULL);
    }
    for(i=0; i<threadNum; i++) {
//        printScanPara(scanThreadArg[i]);
    }

    // compare array2 to the rec and record the same number in res
    pthread_t comThreads[threadNum];
    struct comPara *comThreadArg[threadNum];
    internal = readThreadArg[1]->number / threadNum;
    if(readThreadArg[1]->number % threadNum ==0) internal = readThreadArg[1]->number / threadNum;
    else internal = readThreadArg[1]->number / threadNum + 1;
//    printf("internal = %ld\n", internal);

    int *res[threadNum];
    for(i=0; i<threadNum; i++) {
        res[i] = (int *)calloc(maxmum(readThreadArg[0]->number, readThreadArg[1]->number), sizeof(int));
        long leftb = i*internal;
        long rightb;
        if(i<threadNum-1) rightb = (i+1)*internal;
        else rightb = readThreadArg[1]->number;
	res[i] = (int *)calloc(rightb-leftb+2, sizeof(int));
//        printf("the %dth thread compare from %ld to %ld\n", i, leftb, rightb-1);
        comThreadArg[i] = (struct comPara*)malloc(sizeof(struct comPara));
        initComPara(comThreadArg[i], leftb, rightb, readThreadArg[1]->number, readThreadArg[1]->array,
                totalmax+1, rec, 0, res[i]);
        pthread_create(&comThreads[i], NULL, compare, (void *)comThreadArg[i]);
    }
    for(i=0; i<threadNum; i++) {
        pthread_join(comThreads[i], NULL);
    }
    for(i=0; i<threadNum; i++) {
//        printComPara(comThreadArg[i]);
    }

    // free readThreadArgs and rec and scanThreadArgs
    for(i=0; i<2; i++) {
	freeReadPara(readThreadArg[i]);
    }
    free(rec);
    for(i=0; i<threadNum; i++) {
	freeScanPara(scanThreadArg[i]);
    }
    
    // merge the threadNum of sub result
    int resNum = threadNum;
    struct resPara *mergein[resNum];
    for(i=0; i<resNum; i++) {
	mergein[i] = (struct resPara *)malloc(sizeof(struct resPara));
 	initResPara(mergein[i], comThreadArg[i]->resarray, comThreadArg[i]->resnum);
//	printResPara(mergein[i]);
    }
    struct mergePara *mergeout[threadNum];
    while(resNum>1) {
  	int mergeThreadNum = resNum/2;
//	struct mergePara *mergeout[mergeThreadNum];
       	pthread_t mergeThreads[mergeThreadNum];
	for(i=0; i<mergeThreadNum; i++) {
	    mergeout[i] = (struct mergePara *)malloc(sizeof(struct mergePara));
 	    initMergePara(mergeout[i], mergein[i*2]->array, mergein[i*2]->number, mergein[i*2+1]->array, mergein[i*2+1]->number);
            pthread_create(&mergeThreads[i], NULL, pmerge, (void *)mergeout[i]);
	}
	for(i=0; i<mergeThreadNum; i++) {
	    pthread_join(mergeThreads[i], NULL);
//	    printMergePara(mergeout[i]);
	    free(mergein[i*2]);
	    free(mergein[i*2+1]);
	}
	int resnumtemp;
	struct resPara *last;
	if(resNum%2==0) {
	    resnumtemp = mergeThreadNum;
	} else {
	    resnumtemp = mergeThreadNum +1;
	    last = mergein[resNum];
	}

	int k=0;
	for(i=0; i<mergeThreadNum; i++) {
	    mergein[k] = (struct resPara *)malloc(sizeof(struct resPara));
	    initResPara(mergein[k], mergeout[i]->resarray, mergeout[i]->num);
	    k++;
	}

	if(mergeThreadNum%2!=0) mergein[k] = last;
	
	resNum = resnumtemp;
    }
        
    // output to file
    FILE *outfile = fopen(argv[3], "w");

    for(i=0; i<mergein[0]->number;) {
	while(mergein[0]->array[i+1] == mergein[0]->array[i]) i++;
     	fprintf(outfile, "%d\n", mergein[0]->array[i]);
	i++;
    }
    fclose(outfile);

    return 0;
}

void *pmerge(void *input) {
    struct mergePara *args = (struct mergePara *)input;

    long n1 = args->num1;
    long n2 = args->num2;
    long total = args->num1 + args->num2;
    int *res = (int *)malloc((total+2) * sizeof(int));
    args->array1[n1] = (int)MAX;
    args->array2[n2] = (int)MAX;

    long i=0, j=0, k=0;
    for(k=0; k<total; k++) {
 	if(args->array1[i] < args->array2[j]) res[k] = args->array1[i++];
  	else res[k] = args->array2[j++];
    }
    
    args->resarray = res;
    args->num = total;
}

    

void *compare(void *input) {
    struct comPara *args = (struct comPara *)input;

    int i;
    int resk=0;
    for(i=args->leftb; i<args->rightb; i++) {
        int temp = args->array[i];
        if(args->recarray[temp]>0) {
            args->resarray[resk++] = temp;
        }
    }
    args->resnum = resk;
    merge_sort(args->resarray, 0, args->resnum-1);
}

void *scan(void *input) {
    struct scanPara *args = (struct scanPara *)input;

    int i;
    for(i=args->leftb; i<args->rightb; i++) {
        int temp = args->src1array[i];
        args->rec[temp]++;
    }
}


void *readdata(void *input) {
    struct readPara *args = (struct readPara *)input;
   
    int *array;
    FILE *fp = fopen(args->filename, "r");
    if(fscanf(fp, "%ld", &args->number));
    array = (int *)malloc(args->number * sizeof(int));
    long i;
    int tempmax=0;
    for(i=0; i<args->number; i++) {
        if(fscanf(fp, "%d", array+i));
        if(array[i]>tempmax) tempmax = array[i];
    }
    fclose(fp);
    args->max = tempmax;
    args->array = array;
}
