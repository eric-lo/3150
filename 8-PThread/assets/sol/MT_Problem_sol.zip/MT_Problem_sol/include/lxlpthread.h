#include <pthread.h>
#include <stdlib.h>

//#define MAX 1000

struct readPara {
    long number;
    int max;
    char* filename;
    int *array;
};

void printarg(struct readPara *arg) {
    printf("number = %ld\n", arg->number);
    printf("max = %d\n", arg->max);
    printf("filename = %s\n", arg->filename);
    long i;

    int *array = arg->array;
    for (i=0; i<arg->number; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");
}

void freeReadPara(struct readPara *para) {
    free(para->array);
    free(para);
}

struct scanPara {
    long leftb;
    long rightb;
    long srcnum;
    int * src1array;
    long recnum;
    int * rec;
};

void initScanPara(struct scanPara *para, 
        long left, 
        long right, 
        long srcn, 
        int *array, 
        long recn, 
        int *reca) {
    para->leftb = left;
    para->rightb = right;
    para->srcnum = srcn;
    para->src1array = array;
    para->recnum = recn;
    para->rec = reca;
}

void freeScanPara(struct scanPara *para) {
    free(para);
}

void printScanPara(struct scanPara *arg) {
    printf("leftb = %ld\n", arg->leftb);
    printf("rightb = %ld\n", arg->rightb);
    printf("srcnum = %ld\n", arg->srcnum);
    long i;
    for(i=0; i<arg->srcnum; i++) {
        printf("%d ", arg->src1array[i]);
    }
    printf("\n");
    printf("recnum = %ld\n", arg->recnum);
    for(i=0; i<arg->recnum; i++) {
        printf("%d ", arg->rec[i]);
    }
    printf("\n");
}

struct comPara {
    long leftb;
    long rightb;
    long comnum;
    int *array;
    long recnum;
    int *recarray;
    long resnum;
    int *resarray;
};

void initComPara(struct comPara *para,
        long left,
        long right,
        long comn,
        int *arr,
        long recn,
        int *reca,
        long resn,
        int *resa) {
    para->leftb=left;
    para->rightb=right;
    para->comnum=comn;
    para->array=arr;
    para->recnum=recn;
    para->recarray=reca;
    para->resnum=resn;
    para->resarray=resa;
}

void freeComPara(struct comPara *para) {
    free(para->resarray);
    free(para);
}

void printComPara(struct comPara * para) {
    printf("letfb = %ld\n", para->leftb);
    printf("rightb = %ld\n", para->rightb);
    printf("comnum = %ld\n", para->comnum);
    int i;
    for(i=0; i<para->comnum; i++) {
        printf("%d ", para->array[i]);
    }
    printf("\n");
    printf("recnum = %ld\n", para->recnum);
    for(i=0; i<para->recnum; i++) {
        printf("%d ", para->recarray[i]);
    }
    printf("\n");
    printf("resnum = %ld\n", para->resnum);
    for(i=0; i<para->resnum; i++) {
        printf("%d ", para->resarray[i]);
    }
    printf("\n");
}

struct mergePara {
    int *array1;
    long num1;
    int *array2;
    long num2;
    int *resarray;
    long num;
};

void initMergePara(struct mergePara *para, int *arr1, long n1, int *arr2, long n2) {
    para->array1 = arr1;
    para->num1 = n1;
    para->array2 = arr2;
    para->num2 = n2;
}

void printMergePara(struct mergePara *para) {
    long i;
    for(i=0; i<para->num1; i++) {
	printf("%d ", para->array1[i]);
    }
    printf("\n");
    for(i=0; i<para->num2; i++) {
	printf("%d ", para->array2[i]);
    }
    printf("\n");
    for(i=0; i<para->num; i++) {
	printf("%d ", para->resarray[i]);
    }
    printf("\n");
}

struct resPara {
    int *array;
    long number;
};

void initResPara(struct resPara *para, int *arr, long num) {
    para->array = arr;
    para->number = num;
}

void printResPara(struct resPara *para) {
    long i;
    for(i=0; i<para->number; i++) {
	printf("%d ", para->array[i]);
    }
    printf("\n");
}

void freeResPara(struct resPara *para) {
    free(para->array);
    free(para);
}

/*
void merge(int *array, long start, long mid, long end) {
    long i;
    long n1 = mid-start+1;
    long n2 = end-mid;
    int *array1 = (int *)malloc((n1+1) * sizeof(int));
    for(i=0; i<n1; i++) {
        array1[i] = array[start+i];
    }   
    array1[i] = MAX;
    int *array2 = (int *)malloc((n2+1) * sizeof(int));
    for(i=0; i<n2; i++) {
        array2[i] = array[mid+i+1];
    }   
    array2[i] = MAX;

    i=0;
    int k, j=0;
    for(k=start; k<=end; k++) {
//        while(array1[i+1] == array1[i])
//            i++;
//        while(array2[j+1] == array2[j])
//            j++;
        if(array1[i] < array2[j]) array[k] = array1[i++];
        else array[k] = array2[j++];
    }   
}

void merge_sort(int *array, long start, long end) {
    if(start<end) {
        long mid = (start + end) / 2;
        merge_sort(array, start, mid);
        merge_sort(array, mid+1, end);
        merge(array, start, mid, end);
    }   
}*/
