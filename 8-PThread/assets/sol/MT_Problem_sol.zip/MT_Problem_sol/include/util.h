#define MAX 2000000000

long maxmum(long num1, long num2) {
    if(num1<num2) return num2;
    return num1;
}

long stoi(int len, char* numstr) {
    long ret=0;
    int i=0;
    for(i=0; i<len; i++) {
        ret=10*ret+numstr[i]-'0';
    }

    return ret;
}

void merge(int *array, long start, long mid, long end) {
    long i;
    long n1 = mid-start+1;
    long n2 = end-mid;
    int *array1 = (int *)malloc((n1+1) * sizeof(int));
    for(i=0; i<n1; i++) {
        array1[i] = array[start+i];
    }
    array1[i] = (int)MAX;
    int *array2 = (int *)malloc((n2+1) * sizeof(int));
    for(i=0; i<n2; i++) {
        array2[i] = array[mid+i+1];
    }
    array2[i] = (int)MAX;

    i=0;
    int k, j=0;
    for(k=start; k<=end; k++) {
        if(array1[i] < array2[j]) array[k] = array1[i++];
        else array[k] = array2[j++];
    }
    free(array1);
    free(array2);
}

void merge_sort(int *array, long start, long end) {
    if(start<end) {
        long mid = (start + end) / 2;
        merge_sort(array, start, mid);
        merge_sort(array, mid+1, end);
        merge(array, start, mid, end);
    }
}
